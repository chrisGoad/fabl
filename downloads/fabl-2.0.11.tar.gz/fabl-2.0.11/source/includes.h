/*
* Copyright (C) 2004 Map Bureau - http://www.mapbureau.com
*
* This package is Free Software released under the BSD license.
*
* See license.html at the top of this package for the full license terms.
*
*/

// Most code comments temporarily excised, pending review


#include "types.h"
#include "heap.h"
#include "macros.h"
#include "globals.h"
#include "pcode.h"
#ifndef FORIMPORTS
#include "fun.h"
#endif
