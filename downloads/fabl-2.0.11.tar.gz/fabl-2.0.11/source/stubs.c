/*
* Copyright (C) 2004 Map Bureau - http://www.mapbureau.com
*
* This package is Free Software released under the BSD license.
*
* See license.html at the top of this package for the full license terms.
*
*/

// Most code comments temporarily excised, pending review

#include "includes.h"

void fgc1(){}



Binding Compactob_assertDouble(ob x,ob p,double nv,ob tp)
{
return (Binding)nul;
}

void cgiInit()
{
}

void raptorInit() {}
void raptorParseFile() {}
void raptorParseBuf() {}
void raptorParseUri() {}
void init_www() {}
void www_fetch() {}
