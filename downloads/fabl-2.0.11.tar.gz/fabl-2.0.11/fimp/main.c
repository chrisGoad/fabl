/*
* Copyright (C) 2003 Map Bureau - http://www.mapbureau.com
*
* This package is Free Software released under the GNU Lesser General Public License (LGPL)
*
* See license.html at the top of this package for the full license terms.
*
*/

// Code comments temporarily excised, pending review

